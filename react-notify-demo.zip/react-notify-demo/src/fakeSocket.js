let intervalId = null;

export function startFakeSocket(onMessage) {
  intervalId = setInterval(() => {
    const payload = {
      title: "New Message",
      body: "You have a new notification",
      url: "/"
    };
    onMessage(payload);
  }, 5000);
}

export function stopFakeSocket() {
  clearInterval(intervalId);
}
