import { useState, useEffect } from "react";
import { login, logout, isLoggedIn } from "./auth";
import { startFakeSocket, stopFakeSocket } from "./fakeSocket";
import { showBrowserNotification } from "./notification";

import { requestNotificationPermission } from "./notificationPermission";
import "./styles.css";

export default function App() {
  const [logged, setLogged] = useState(isLoggedIn());
  const [notifications, setNotifications] = useState([]);
  const [showNotifBanner, setShowNotifBanner] = useState(false);

  useEffect(() => {
    if (!logged) return;

    // Show permission banner only once
    if (
      Notification.permission === "default" &&
      !localStorage.getItem("notifPromptDismissed")
    ) {
      setShowNotifBanner(true);
    }

    startFakeSocket((data) => {
      setNotifications((prev) => [data, ...prev]);
      showBrowserNotification(data);
    });

    return () => stopFakeSocket();
  }, [logged]);

  const handleLogin = () => {
    login();
    setLogged(true);
  };

  const handleLogout = () => {
    logout();
    stopFakeSocket();
    setLogged(false);
    setNotifications([]);
    setShowNotifBanner(false);
  };

  const handleEnableNotifications = async () => {
    const result = await requestNotificationPermission();
    setShowNotifBanner(false);

    if (result !== "granted") {
      localStorage.setItem("notifPromptDismissed", "true");
    }
  };

  const handleDismissNotifications = () => {
    localStorage.setItem("notifPromptDismissed", "true");
    setShowNotifBanner(false);
  };

  return (
    <div className="container">
      <h1>Teams-style Web Notifications</h1>

      {!logged ? (
        <button onClick={handleLogin}>Login</button>
      ) : (
        <>
          <button onClick={handleLogout}>Logout</button>

          {/* Notification permission banner */}
          {showNotifBanner && (
            <div className="notif-banner">
              <span>🔔 Enable desktop notifications to stay updated</span>
              <div>
                <button onClick={handleEnableNotifications}>Enable</button>
                <button onClick={handleDismissNotifications}>Not now</button>
              </div>
            </div>
          )}

          <h2>In-app notifications</h2>
          <ul>
            {notifications.map((n, i) => (
              <li key={i}>
                <strong>{n.title}</strong> — {n.body}
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}
