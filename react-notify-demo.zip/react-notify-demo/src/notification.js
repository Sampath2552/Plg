export function showBrowserNotification(data) {
  if (Notification.permission !== "granted") return;

  const isUserActivelyViewing =
    document.visibilityState === "visible" 
    // document.hasFocus();

    console.log("User actively viewing:", isUserActivelyViewing);
    console.log(document.visibilityState,document.hasFocus());

  // Teams behavior: never notify if user is already looking
  if (isUserActivelyViewing) return;

  const notification = new Notification(data.title, {
    body: data.body,
    icon: data.icon || "/vite.svg",
    tag: data.id || "new-message",
    requireInteraction: true,
    silent: false,
  });

  notification.onclick = (event) => {
    event.preventDefault();
    window.focus();
    notification.close();
  };
}
